-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-06-2021 a las 00:37:00
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `algar`
--
CREATE DATABASE IF NOT EXISTS `algar` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `algar`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido`
--

CREATE TABLE `pedido` (
  `Usuario` varchar(20) NOT NULL,
  `ID_producto` varchar(4) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `imagen` text NOT NULL,
  `Nombre` text NOT NULL,
  `Talla` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros`
--

CREATE TABLE `registros` (
  `ID_Registro` int(4) NOT NULL,
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `Email` varchar(120) NOT NULL,
  `Usuario` varchar(20) NOT NULL,
  `Contraseña` varchar(12) NOT NULL,
  `Telefono` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `registros`
--

INSERT INTO `registros` (`ID_Registro`, `Nombres`, `Apellidos`, `Email`, `Usuario`, `Contraseña`, `Telefono`) VALUES
(1, 'Luis', 'Ibarra', 'luisibarra@gmail.com', 'LuisIbarra', 'Luis123', 713313131),
(1010, 'Admin', 'Admin', 'admin@gmail.com', 'Admin', 'Gearsofwar3', 0),
(1015, 'Mario Alberto', 'Vázquez Anaya', 'marioavazquez2011@gmail.com', 'MarioKaiju', 'Gearsofwar3', 2147483647),
(1016, 'Mario Alberto', 'Anaya', 'marioavazquez2011@hotmail.com', 'MKaiju', 'Gearsofwar3', 2147483647);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stock`
--

CREATE TABLE `stock` (
  `ID` varchar(4) NOT NULL,
  `nombre_producto` text NOT NULL,
  `precio` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `imagen` text NOT NULL,
  `descripcion` text NOT NULL,
  `caracteristicas` text NOT NULL,
  `frase` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `stock`
--

INSERT INTO `stock` (`ID`, `nombre_producto`, `precio`, `cantidad`, `imagen`, `descripcion`, `caracteristicas`, `frase`) VALUES
('0125', 'Jeans Levis', 949, 28, 'img/jeans.jpg', 'LEVI\'S® 511® SLIM FIT', 'TALLA: 28, 29, 30, 31, 32, 33, 34', '<p>Los 511® Slim Fit de Levi\'s® están destinados a convertirse en un clásico. Estos pantalones tienen pierna ajustada desde la cadera hasta el tobillo, sin embargo, son muy cómodos y te permiten gran movilidad. Añade esta pieza avanzada a tu estilo.</p>\r\n<p>Su elaboración a partir de algodón orgánico te permitirá ser parte de una nueva forma de vestir de manera responsable.</p>\r\n<ul>\r\n<li>\r\nPierna slim de la cadera al tobillo</li>\r\n<li>\r\nAjustados, pero con adecuado espacio para moverte libremente</li>\r\n<li>\r\nCintura media</li>\r\n<li>\r\nLyocell®</li>\r\n<li>\r\nCon tecnología Levi\'s® Flex</li>\r\n<li>\r\nElaborados con algodón orgánico</li>\r\n</ul>'),
('0126', 'Shorts', 999, 25, 'img/short.jpg', 'Short Denim', 'TALLA: 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44', 'Tejido de algodón estilo denim. Diseño corto. Diseño recto. Tiro medio. Trabillas. Bolsillos laterales. Bolsillo portamonedas. Bolsillos de parche en la parte posterior. Cierre de cremallera y botón.'),
('4539', 'Vestido Negro', 1799, 3, 'img/vestido.jpg', 'Vestido textura cordón', '<p>Colección Committed. Diseño maxi vestido. Diseño acampanado. Diseño largo. Escote de pico. Sin mangas. Tirantes anchos. Cordón ajustable en la cintura. Cierre de cremallera en la parte posterior. Abertura lateral. Forro interior. Colección fiesta.</p>\r\n<p>\r\nLas prendas etiquetadas como Committed son productos que han sido confeccionadas con fibras y/o procesos de producción sostenible, reduciendo así su impacto ambiental. El objetivo de Mango es respaldar la implementación de prácticas más comprometidas con el medio ambiente, aumentando así, el número de prendas sostenibles en su colección.</p>', '<p>Colección Committed. Diseño maxi vestido. Diseño acampanado. Diseño largo. Escote de pico. Sin mangas. Tirantes anchos. Cordón ajustable en la cintura. Cierre de cremallera en la parte posterior. Abertura lateral. Forro interior. Colección fiesta.</p>\r\n<p>\r\nLas prendas etiquetadas como Committed son productos que han sido confeccionadas con fibras y/o procesos de producción sostenible, reduciendo así su impacto ambiental. El objetivo de Mango es respaldar la implementación de prácticas más comprometidas con el medio ambiente, aumentando así, el número de prendas sostenibles en su colección.</p>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tallas`
--

CREATE TABLE `tallas` (
  `ID` varchar(4) NOT NULL,
  `Talla` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tallas`
--

INSERT INTO `tallas` (`ID`, `Talla`) VALUES
('0125', '28'),
('0125', '29'),
('0125', '30'),
('0125', '31'),
('0125', '32'),
('0125', '33'),
('0125', '34'),
('0125', '35'),
('0125', '36'),
('0126', '32'),
('0126', '33'),
('0126', '34'),
('0126', '35'),
('0126', '36'),
('0126', '37'),
('0126', '38'),
('0126', '39'),
('0126', '40'),
('0126', '41'),
('0126', '42'),
('0126', '43'),
('0126', '44'),
('4539', 'CH'),
('4539', 'EG'),
('4539', 'G'),
('4539', 'M'),
('4539', 'XCH');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`ID_producto`,`Usuario`,`Talla`) USING BTREE,
  ADD KEY `Usuario_pedido` (`Usuario`);

--
-- Indices de la tabla `registros`
--
ALTER TABLE `registros`
  ADD PRIMARY KEY (`ID_Registro`),
  ADD UNIQUE KEY `ID_Registro` (`ID_Registro`) USING BTREE,
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Usuario` (`Usuario`);

--
-- Indices de la tabla `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `tallas`
--
ALTER TABLE `tallas`
  ADD PRIMARY KEY (`ID`,`Talla`) USING BTREE;

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `registros`
--
ALTER TABLE `registros`
  MODIFY `ID_Registro` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1017;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `ID_pedido` FOREIGN KEY (`ID_producto`) REFERENCES `stock` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Usuario_pedido` FOREIGN KEY (`Usuario`) REFERENCES `registros` (`Usuario`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tallas`
--
ALTER TABLE `tallas`
  ADD CONSTRAINT `ID_stock` FOREIGN KEY (`ID`) REFERENCES `stock` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
