<?php
    require ('conexion.php');

    $ArregloPrecio = array();
    $ArregloImagen = array();
    $ArregloDescripcion = array();
    $ArregloNombre = array();

    $sql = "SELECT * FROM stock";
    $resultado = $conexion->query($sql);

    if($resultado->num_rows > 0)
    {
        while($row=$resultado->fetch_assoc())
        {
            array_push ($ArregloPrecio, $row["precio"]);
            array_push ($ArregloImagen, $row["imagen"]);
            array_push ($ArregloDescripcion, $row["descripcion"]);
            array_push ($ArregloNombre, $row["nombre_producto"]);
        }   
    }

    $conexion->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/stylePHP.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header class="site-header">
        <div class="contenedor contenido-header">
            <div class="barra">
                <div>
                    <a href="index.php">
                        <img src="img/Logo.svg" alt="Logotipo de la pagina">
                    </a>
                </div>
                <nav id="navegacion" class="navegacion alinear-navegador">
                    <div>
                        <a href="Nosotros.php">Conocenos</a>
                        <a href="Productos.php">Catalogo</a>
                        <a href="Vision.php">Vision</a>
                        <a href="Contacto.php">Contacto</a>
                        <?php
                        if($VarSession == NULL || $VarSession = '')
                        {
                            echo '<a href="Login.html">Inicia Sesion</a>';
                        }
                        else
                        {
                            echo '
                            <a href="CerrarSesion.php">Cerrar Sesion</a>
                        ';
                        }
                        ?>
                    </div>
                    <div class="alinear agrupar">
                        <div>
                        <a href="Carrito.php">Carrito de compra</div><div><img class ="carrito"src="img/carrito.png" alt="Carrito de Compra"></div></a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="contenedor site-main">
    <center>
            <div id="blink">Encuentra los mejores productos aqui!</div>
            <div id="blink" onclick="parent.location='http://norfipc.com'"></div>
        </center>
        <h2 class="centrar-texto fw-400">Gran variedad de productos y marcas</h2>
            <div class="contenedor-anuncio">
                <?php
                $i=0;
                while ($i < count ($ArregloPrecio))
                {
                echo'
                <div class="anuncio anuncio-producto">
                    <img src="'.$ArregloImagen[$i].'" alt="Anuncio Producto">
                    <div class="contenido-anuncio">
                        <div class="texto-anuncio">
                            <h3>'.$ArregloNombre[$i].'</h3>
                            <p>'.$ArregloDescripcion[$i].'</p>
                            <p class="precio"> $'.number_format($ArregloPrecio[$i], 0, '.', ',').'</p>
                        </div>
                        <div class="contenedor-boton">
                            <form action="Comprar.php" method="POST">
                                    <input type="hidden" value="'.$ArregloNombre[$i].'" name="Nombre">
                                    <input type="hidden" value="'.$ArregloImagen[$i].'" name="Imagen">
                                    <input type="hidden" value="'.$ArregloPrecio[$i].'" name="Precio">
                                    <div>
                                        <input type="submit" class="boton boton-pastel boton-producto d-block tamaño-boton" value="Ver Producto">
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>';
                $i++;
                }
                ?>
            </div>
            <script>
            window.setInterval(BlinkIt, 600);
            var color = "red";

            function BlinkIt() {
                var blink = document.getElementById("blink");
                color = (color == "#ffffff") ? "#7d00c8" : "#ffffff";
                blink.style.color = color;
                blink.style.fontSize = '36px';
            }
        </script>
    </main>

    <footer class="site-footer seccion">
        <div class="contenedor contenedor-footer">
            <div class="agrupar">
                <nav class="navegacion">
                    <a href="Nosotros.php">Conocenos</a>
                    <a href="Productos.php">Catalogo</a>
                    <a href="Vision.php">Vision</a>
                    <a href="Contacto.php">Contacto</a>
                </nav>
                <p class="copyright">ALGAR &copy;
                </p>
            </div>
            <div class="agrupar fw-400">
                <p>Torreón, Coahuila México</p>
                <p>marian.garza187@gmail.com</p>
                <p>tel: 8713351802</p>
            </div>
        </div>
    </footer>
</body>
</html>

