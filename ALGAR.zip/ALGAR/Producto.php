<?php
    
    require ('conexion.php');
    if($VarSession == NULL || $VarSession = ''){
        echo "<script> alert('Usted no tiene una cuenta');
        window.location ='Login.html';</script>";
        die();
    }
    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/stylePHP.css">
</head>

<body>
    <header class="site-header">
        <div class="contenedor contenido-header">
            <div class="barra">
                <div>
                    <a href="index.php">
                        <img src="img/Logo.svg" alt="Logotipo de la pagina">
                    </a>
                </div>
                <nav id="navegacion" class="navegacion alinear-navegador">
                    <div>
                        <a href="Nosotros.php">Conocenos</a>
                        <a href="Productos.php">Catalogo</a>
                        <a href="Vision.php">Vision</a>
                        <a href="Contacto.php">Contacto</a>
                        <a href="CerrarSesion.php">Cerrar Sesion</a>
                    </div>
                    <div class="alinear agrupar">
                        <div>
                        <a href="Carrito.php">Carrito de compra</div><div><img class ="carrito"src="img/carrito.png" alt="Carrito de Compra"></div></a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="site-main">
        <div class="fondo">
        <h2 class="centrar-texto fw-400 barra-producto">Producto agregado al Carrito</h2>
            <div class="contenedor-anuncio-producto contenedor">
                <div class="cantidad-producto">
                    <?php
                    
                    echo
                    '<img src="'.$_POST['Imagen'].'" alt="Anuncio">'
                    ?>
               
                </div>
                <div class="contenido-anuncio-producto espacio centrar">
                                <?php
                                $Precio = $_POST['Precio'];
                                $Cantidad = $_POST['Cantidad'];
                                $Total = $Precio * $Cantidad;
                                $Talla = $_POST['opciones'];
                                echo '<p class="fw-700 font-size">Producto: '.$_POST['Producto'].'</p><p class="fw-700 font-size">Cantidad: '.$_POST['Cantidad'].'</p><p class="fw-700 font-size">Talla: '.$_POST['opciones'].'</p><div class="agrupar"><p class="fw-700 font-size">Costo: <p class="fw-700 font-size precio">$'.number_format($Total, 0, '.', ',').'</p></p></div>';
                                ?>
                                <a href="Productos.php" class="boton boton-morado">Seguir Comprando</a>
                </div>
            </div>
        </div>
        <div class="contenedor ver-productos">
        <a href="Productos.php" class="boton boton-azul">Seguir comprando</a> 
        </div>   
    </main> 

    <footer class="site-footer seccion">
        <div class="contenedor contenedor-footer">
            <div class="agrupar">
                <nav class="navegacion">
                    <a href="Nosotros.php">Conocenos</a>
                    <a href="Productos.php">Catalogo</a>
                    <a href="Vision.php">Vision</a>
                    <a href="Contacto.php">Contacto</a>
                </nav>
                <p class="copyright">ALGAR &copy;
                </p>
            </div>
            <div class="agrupar fw-400">
                <p>Torreón, Coahuila México</p>
                <p>marian.garza187@gmail.com</p>
                <p>tel: 8713351802</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php
    $Precio = $_POST['Precio'];
    $Cantidad = $_POST['Cantidad'];
    $Total = $Precio * $Cantidad;
    $ID_Producto = $_POST['IdProducto'];
    $Nombre = $_POST['Producto'];
    $Imagen = $_POST['Imagen'];
    $usuario = $_SESSION['User'];

    if(isset($ID_Producto)){
        $sql = "INSERT INTO pedido(Usuario, ID_Producto, Nombre, Cantidad,Total, Imagen, Talla)
                VALUES('$usuario','$ID_Producto','$Nombre',$Cantidad,$Total, '$Imagen', '$Talla')";

        if($conexion->query($sql) == true){
            //echo '<div><form action=""><input type ="checkbox">'.$texto.'</form></div>';
        }
        else {
            $sql ="UPDATE pedido set Cantidad = pedido.Cantidad + $Cantidad, Total = pedido.Total + $Total where ID_Producto like '$ID_Producto' and Usuario like '$usuario' and Talla like '$Talla'";
            if($conexion->query($sql) == true){
            //echo '<div><form action=""><input type ="checkbox">'.$texto.'</form></div>';
            }
            else {
                echo 'error';
                die("Error al insertar datos: ". $conexion->error);

            }
        }
    }   
?>