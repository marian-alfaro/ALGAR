<?php
require ('conexion.php');

$Nombre = $_POST['Usuario'];

$Contraseña = $_POST['Password'];

//SE INICIALIZA LA VARIABLE SESIÓN CON EL USUARIO QUE RECIBIO (YA NO ES  NULA)

$_SESSION['User'] = $Nombre;

$Registrado = "SELECT * FROM `registros` WHERE Usuario = '" . $Nombre . "' AND Contraseña = '" . $Contraseña . "'";
//$Nuevo = "INSERT INTO inicio('Usuario','Password') VALUES ('usuario','contraseña')";

$query = mysqli_query($conexion, $Registrado);

$filas = mysqli_num_rows($query);

if($filas > 0 && $Nombre == "Admin" && $Contraseña == "Marian18131213")
{
        echo "<script> alert('Bienvenido Admin');
        window.location ='Admin.php';</script>";
}
else if($filas > 0){
    header("Location:Productos.php");
}else{
    echo "<script>alert ('Crea una cuenta para comprar')</script>";
}

mysqli_free_result($query);

mysqli_close($conexion);
?>