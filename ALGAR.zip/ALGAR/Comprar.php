<?php
require ('conexion.php');

    $Precio = $_POST['Precio'];
    $Imagen= $_POST['Imagen'];
    $Nombre = $_POST['Nombre'];
    $Propiedades = "";
    $Frase = "";
    $IdProducto ="";
    $cantidad = 0;
    $ArregloTallas = array ();
    $sql = "SELECT * FROM stock where nombre_producto = '$Nombre'";
    $resultado = $conexion->query($sql);

    if($resultado !== false && $resultado->num_rows > 0)
    {
        while($row=$resultado->fetch_assoc())
            {
            $Propiedades = $row["descripcion"];
            $Frase = $row["frase"];
            $IdProducto = $row["ID"];
            $cantidad = $row["cantidad"];
            }
    }

    $sql = "SELECT * FROM tallas where ID = '$IdProducto'";
    $resultado = $conexion->query($sql);
    $i =0;
    if($resultado !== false && $resultado->num_rows > 0)
    {
        while($row=$resultado->fetch_assoc())
            {
            array_push ($ArregloTallas, $row["Talla"]);
            }
    }
    $conexion->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/stylePHP.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header class="site-header">
        <div class="contenedor contenido-header">
            <div class="barra">
                <div>
                    <a href="index.php">
                        <img src="img/Logo.svg" alt="Logotipo de la pagina">
                    </a>
                </div>
                <nav id="navegacion" class="navegacion alinear-navegador">
                    <div>
                        <a href="Nosotros.php">Conocenos</a>
                        <a href="Productos.php">Catalogo</a>
                        <a href="Vision.php">Vision</a>
                        <a href="Contacto.php">Contacto</a>
                        <?php
                        if($VarSession == NULL || $VarSession = '')
                        {
                            echo '<a href="Login.html">Inicia Sesion</a>';
                        }
                        else
                        {
                            echo '
                            <a href="CerrarSesion.php">Cerrar Sesion</a>
                        ';
                        }
                        ?>
                    </div>
                    <div class="alinear agrupar">
                        <div>
                        <a href="Carrito.php">Carrito de compra</div><div><img class ="carrito"src="img/carrito.png" alt="Carrito de Compra"></div></a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="site-main">
        <?php
        echo '
        <div class="fondo">
        <h2 class="centrar-texto fw-400 barra-producto">'.$Nombre.'</h2>
            <div class="contenedor-anuncio-producto contenedor">
                <div class="cantidad-producto">
                    <img src="'.$Imagen.'" alt="Anuncio">
                </div>
                <div class="contenido-anuncio-producto">
                        <div class="fw-700">
                            <h3>'.$Propiedades.'
                            </h3>
                        </div>
                        <div>
                            <p>
                                '.$Frase.'
                            </p>
                            <p class="fw-700">';
                            if ( $cantidad == 0 )
                            echo 'Agotado';
                            
                            else
                            echo'
                                En stock: '.$cantidad.'
                            </p>
                            <p class="precio">$'.number_format($Precio, 0, '.', ',').'</p>
                            <form action="Producto.php" method="POST">
                                <input type="hidden" value="'.$Nombre.'" name="Producto">
                                <input type="hidden" value="'.$Precio.'" name="Precio">
                                <input type="hidden" value="'.$IdProducto.'" name="IdProducto">
                                <input type="hidden" value="'.$Imagen.'" name="Imagen">
                                <div style="display:flex;">
                                    <INPUT class="spinner" type="NUMBER" min="0" max="'.$cantidad.'" step="1" value="1" size="2" name="Cantidad" required>
                                    <select name="opciones" class="sel-tallas" required>
                                        <option value="" disabled selected>-- Seleccione Talla --</option>';
                                    $i = 0;
                                    while ( $i < count ($ArregloTallas))
                                    {
                                        echo '
                                        <option value="'.$ArregloTallas[$i].'">'.$ArregloTallas[$i].'</option>';
                                        $i++;
                                    }
                                    echo'
                                    </select>
                                </div>
                                <input type="submit" class="boton boton-morado boton-producto" value="Agregar Producto">
                            </form>
                        </div>
                </div>
            </div>
        </div>';
        ?>
    </main>

    <footer class="site-footer seccion">
        <div class="contenedor contenedor-footer">
            <div class="agrupar">
                <nav class="navegacion">
                    <a href="Nosotros.php">Conocenos</a>
                    <a href="Productos.php">Catalogo</a>
                    <a href="Vision.php">Vision</a>
                    <a href="Contacto.php">Contacto</a>
                </nav>
                <p class="copyright">ALGAR &copy;
                </p>
            </div>
            <div class="agrupar fw-400">
                <p>Torreón, Coahuila México</p>
                <p>marian.garza187@gmail.com</p>
                <p>tel: 8713351802</p>
            </div>
        </div>
    </footer>
</body>
</html>