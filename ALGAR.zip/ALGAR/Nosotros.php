<?php
    require ('conexion.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/stylePHP.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header class="site-header">
        <div class="contenedor contenido-header">
            <div class="barra">
                <div>
                    <a href="index.php">
                        <img src="img/Logo.svg" alt="Logotipo de la pagina">
                    </a>
                </div>
                <nav id="navegacion" class="navegacion alinear-navegador">
                    <div>
                        <a href="Nosotros.php">Conocenos</a>
                        <a href="Productos.php">Catalogo</a>
                        <a href="Vision.php">Vision</a>
                        <a href="Contacto.php">Contacto</a>
                        <?php
                        require('conexion.php');
                        if($VarSession == NULL || $VarSession = '')
                        {
                            echo '<a href="Login.html">Inicia Sesion</a>';
                        }
                        else
                        {
                            echo '
                            <a href="CerrarSesion.php">Cerrar Sesion</a>
                        ';
                        }
                        ?>
                    </div>
                    <div class="alinear agrupar">
                        <div>
                        <a href="Carrito.php">Carrito de compra</div><div><img class ="carrito"src="img/carrito.png" alt="Carrito de Compra"></div></a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="contenedor contenedor-quienes">
        <h2>¿Quienes somos?</h2>
        <div class="contenedor-nosotros">
            <img src="img/moda.jpg" alt="Marcas">
            <div class="justificar-texto contenedor-texto">
                <p>Dolor sit amet consectetur adipisicing elit.
                    Quaerat corrupti pariatur illum nisi totam, fuga aliquid blanditiis, eos quis voluptatem
                    tempora molestias voluptatum cum mollitia assumenda sit illo excepturi optio.
                </p>
                <p>
                    Nullam ut facilisis libero, vel eleifend augue. Integer porttitor, ligula at aliquet fermentum,
                    diam dui congue sem, vitae tempor ipsum dolor vitae purus. Integer vitae ultricies sem.
                    Praesent sed mauris non erat congue feugiat in vitae ipsum. In varius sed ipsum pellentesque
                    rutrum. Sed luctus fermentum purus, at efficitur nibh venenatis ut. Phasellus dignissim lobortis efficitur.
                </p>
                <p>
                    Vivamus eget ligula pretium tortor placerat viverra condimentum sed velit. Fusce id neque auctor, porta 
                    risus a, scelerisque magna. Donec lectus ante, feugiat eget mollis quis, auctor pretium sapien. Aenean sodales venenatis
                    lacinia. Curabitur vitae commodo libero, sit amet scelerisque nibh. Nam aliquam lectus sed felis dapibus suscipit.
                    Ut eget feugiat eros, sit amet hendrerit leo. Nunc sed enim vitae felis condimentum luctus in a tortor. 
                    Morbi aliquam nisl tortor, id semper sem vehicula at.
                </p>
                <p>
                    Maecenas aliquet magna in ornare ullamcorper. Pellentesque malesuada vitae massa quis sagittis.
                    Ut ut magna lacinia, interdum augue in, blandit orci. Morbi tristique augue nec vestibulum laoreet. Maecenas dignissim pellentesque facilisis.
                    Ut ac rhoncus orci. Etiam elementum dolor quis condimentum viverra. Vestibulum non ullamcorper mauris. Proin semper dolor
                    ut sagittis placerat. Mauris orci ipsum, ultricies sit amet ipsum eu, euismod dapibus lorem.
                </p>
                <p>
                    Vivamus eget ligula pretium tortor placerat viverra condimentum sed velit. Fusce id neque auctor, porta 
                    risus a, scelerisque magna. Donec lectus ante, feugiat eget mollis quis, auctor pretium sapien. Aenean sodales venenatis
                    lacinia. Curabitur vitae commodo libero, sit amet scelerisque nibh. Nam aliquam lectus sed felis dapibus suscipit.
                    Ut eget feugiat eros, sit amet hendrerit leo. Nunc sed enim vitae felis condimentum luctus in a tortor. 
                    Morbi aliquam nisl tortor, id semper sem vehicula at.
                    Nullam ut facilisis libero, vel eleifend augue. Integer porttitor, ligula at aliquet fermentum,
                    diam dui congue sem, vitae tempor ipsum dolor vitae purus. Integer vitae ultricies sem.
                    Praesent sed mauris non erat congue feugiat in vitae ipsum. In varius sed ipsum pellentesque
                    rutrum. Sed luctus fermentum purus, at efficitur nibh venenatis ut. Phasellus dignissim lobortis efficitur.
                </p>
            </div>
        </div>
    </main>


    <footer class="site-footer seccion">
        <div class="contenedor contenedor-footer">
            <div class="agrupar">
                <nav class="navegacion">
                    <a href="Nosotros.php">Conocenos</a>
                    <a href="Productos.php">Catalogo</a>
                    <a href="Vision.php">Vision</a>
                    <a href="Contacto.php">Contacto</a>
                </nav>
                <p class="copyright">ALGAR &copy;
                </p>
            </div>
            <div class="agrupar fw-400">
                <p>Torreón, Coahuila México</p>
                <p>marian.garza187@gmail.com</p>
                <p>tel: 8713351802</p>
            </div>
        </div>
    </footer>
</body>


</html>