
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/stylePHP.css">
</head>
<main class="contenedor">
<?php
    require ('conexion.php');
    $ID_Original = $_POST['ID_Original'];
    $ID= $_POST['ID'];
    $Nombre_Producto = $_POST['Nombre'];
    $Precio = $_POST['Precio'];
    $Cantidad = $_POST['Cantidad'];
    $Descripcion = $_POST['Descripcion'];
    $Imagen = $_POST['Imagen'];
    $Caracteristicas = $_POST['Caracteristicas'];
    $CadenaTallas = $_POST['Tallas'];
    $Tallas = explode ('-', $CadenaTallas);

    if($conexion->connect_error) {
        die("Conexión fallida: " . $conexion ->connect_error);
    }
    
    if(isset($ID)){
        $sql = "INSERT INTO stock(ID, nombre_producto, precio, cantidad, descripcion, imagen, frase, caracteristicas)
                VALUES('$ID','$Nombre_Producto',$Precio, $Cantidad,'$Descripcion', '$Imagen', '$Caracteristicas', '')";

        if($conexion->query($sql) == true){
            {
                echo "<script> alert('Producto Insertado');</script>";
                echo "<a href='Admin.php' class='boton boton-morado'>Volver </a>";
            }
            $i = 0;
            while ( $i <  count ( $Tallas ) )
            {
                $Talla = $Tallas [$i];
                $sql = "INSERT INTO tallas(ID, Talla) VALUES('$ID','$Talla')";
                $conexion->query($sql);
                $i++;
            }
        }
        else {
            $sql ="UPDATE stock set ID = '$ID', nombre_producto = '$Nombre_Producto', precio = $Precio, cantidad = $Cantidad,
            descripcion = '$Descripcion', imagen = '$Imagen', frase = '$Caracteristicas' where ID like '$ID_Original'";
            if($conexion->query($sql) == true)
            {
                echo "<script> alert('Cambios Guardaros');</script>";
                echo "<a href='admin.php' class='boton boton-azul'>Volver </a>";
                $i = 0;
                $sql = "DELETE from tallas where ID = $ID_Original";
                    $conexion->query($sql);
                while ( $i <  count ( $Tallas ) )
                {
                    $Talla = $Tallas [$i];
                    $sql = "INSERT INTO tallas(ID, Talla)
                    VALUES('$ID','$Talla')";
                    $conexion->query($sql);
                    $i++;
                }
            }
            else {
                die("Error al insertar datos: ". $conexion->error);

            }
        }
    }
?>
</main>
</html>

