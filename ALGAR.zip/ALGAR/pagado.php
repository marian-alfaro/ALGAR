<?php
    require ('conexion.php');

    if($VarSession == NULL || $VarSession = ''){
        echo "<script> alert('Usted no tiene una cuenta');
        window.location ='Login.html';</script>";
        die();
    }

    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/stylePHP.css">
</head>
<main class="contenedor">
<?php

    require ('conexion.php');
    $ArregloPrecio = array();
    $ArregloCantidad = array();
    $ArregloNombre = array();
    $ArregloImagenes = array();
    $Total = 0;
    $ArregloID_Producto = array();

    $sql = "SELECT * FROM pedido where Usuario = '".$usuario."'";
    $resultado = $conexion->query($sql);

    if($resultado->num_rows > 0)
    {
        while($row=$resultado->fetch_assoc())
        {
            array_push ($ArregloCantidad, $row["Cantidad"]);
            array_push ($ArregloID_Producto, $row["ID_producto"]);
        }   
    }

    else
    {
        echo '<h4 class="sin-productos">Carrito sin Productos</h4>';
    }
    $i=0;
    while ($i < count ($ArregloID_Producto))
    {
        $sql ="UPDATE stock set cantidad = stock.cantidad - $ArregloCantidad[$i] where ID like '$ArregloID_Producto[$i]'";
        if($conexion->query($sql) == true){
                $sql = 'DELETE from pedido where ID_producto = "'.$ArregloID_Producto[$i].'" and Usuario = "'.$usuario.'"';
                $conexion->query($sql);
            }
            else {
                die("Error al insertar datos: ". $conexion->error);

            }
        $i++;
    }
    echo "<script> alert('Pago realizado');</script>";
    echo "<a href='Productos.php' class='boton boton-morado'>Volver </a>";

?>
</main>
</html>