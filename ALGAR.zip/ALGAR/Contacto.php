<?php
    require ('conexion.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/stylePHP.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header class="site-header">
        <div class="contenedor contenido-header">
            <div class="barra">
                <div>
                    <a href="index.php">
                        <img src="img/Logo.svg" alt="Logotipo de la pagina">
                    </a>
                </div>
                <nav id="navegacion" class="navegacion alinear-navegador">
                    <div>
                        <a href="Nosotros.php">Conocenos</a>
                        <a href="Productos.php">Catalogo</a>
                        <a href="Vision.php">Vision</a>
                        <a href="Contacto.php">Contacto</a>
                        <?php
                        require ('conexion.php');
                        if($VarSession == NULL || $VarSession = '')
                        {
                            echo '<a href="Login.html">Inicia Sesion</a>';
                        }
                        else
                        {
                            echo '
                            <a href="CerrarSesion.php">Cerrar Sesion</a>
                        ';
                        }
                        ?>
                    </div>
                    <div class="alinear agrupar">
                        <div>
                        <a href="Carrito.php">Carrito de compra</div><div><img class ="carrito"src="img/carrito.png" alt="Carrito de Compra"></div></a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

        <main class="contenedor seccion-contacto contenido-centrado">
            <h2 class="fw-400 centrar-texto">Llena el formulario de Contacto</h2>
            
            <form class="contacto" action="">
                <fieldset>
                    <legend>Información Personal</legend>
                    <label for="nombre">Nombre: </label>
                    <input type="text" id="nombre" placeholder="Tu Nombre">

                    <label for="email">E-mail: </label>
                    <input type="email" id="email" placeholder="Tu Correo electrónico" required>

                    <label for="telefono">Teléfono: </label>
                    <input type="tel" id="telefono" placeholder="Tu teléfono" required>

                    <label for="mensaje">Mensaje: </label>
                    <textarea id="mensaje"></textarea>

                </fieldset>

                <fieldset>
                    <legend>Contacto</legend>

                    <p>Como desea ser contactado: </p>

                    <div class="forma-contacto">
                        <label for="telefono">Teléfono</label>
                        <input type="radio" name="contacto" value="telefono" id="telefono">
                        
                        <label for="correo">E-mail</label>
                        <input type="radio" name="contacto" value="correo" id="correo">
                    </div>

                    <p>Si eligió Teléfono, elija la fecha y la hora</p>
                    <label for="fecha">Fecha: </label>
                    <input type="date" id="fecha">

                    <label for="hora">Hora: </label>
                    <input type="time" id="hora" nub="9:00" max="18:00">
                </fieldset>

                <input type="submit" value="Enviar" class="boton boton-morado">
            </form>
    </main>
    <footer class="site-footer seccion">
        <div class="contenedor contenedor-footer">
            <div class="agrupar">
                <nav class="navegacion">
                    <a href="Nosotros.php">Conocenos</a>
                    <a href="Productos.php">Catalogo</a>
                    <a href="Vision.php">Vision</a>
                    <a href="Contacto.php">Contacto</a>
                </nav>
                <p class="copyright">ALGAR &copy;
                </p>
            </div>
            <div class="agrupar fw-400">
                <p>Torreón, Coahuila México</p>
                <p>marian.garza187@gmail.com</p>
                <p>tel: 8713351802</p>
            </div>
        </div>
    </footer>
</body>


</html>