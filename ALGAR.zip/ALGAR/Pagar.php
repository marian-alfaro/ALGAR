<?php
    require ('conexion.php');

    if($VarSession == NULL || $VarSession = ''){
        echo "<script> alert('Usted no tiene una cuenta');
        window.location ='Login.html';</script>";
        die();
    }

    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/stylePHP.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="fondo">
    
<div class="container-fluid">
    <header class="site-header">
        <div class="contenedor contenido-header">
            <div class="barra">
                <div>
                    <a href="index.php">
                        <img src="img/Logo.svg" alt="Logotipo de la pagina">
                    </a>
                </div>
                
                <nav id="navegacion" class="navegacion alinear-navegador">
                    <div>
                        <a href="Nosotros.php">Conocenos</a>
                        <a href="Productos.php">Catalogo</a>
                        <a href="Vision.php">Vision</a>
                        <a href="Contacto.php">Contacto</a>
                        <?php
                        require('conexion.php');
                        if($VarSession == NULL || $VarSession = '')
                        {
                            echo '<a href="Login.html">Inicia Sesion</a>';
                        }
                        else
                        {
                            echo '
                            <a href="CerrarSesion.php">Cerrar Sesion</a>';
                        }
                        ?>
                    </div>
                    <div class="alinear agrupar">
                        <div>
                        <a href="Carrito.php">Carrito de compra</div><div><img class ="carrito"src="img/carrito.png" alt="Carrito de Compra"></div></a>
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <main class="contenedor seccion-contacto contenido-centrado">
    <div class="creditCardForm">
            <div class="heading">
                <h1>Datos de la tarjeta</h1>
            </div>
            <div class="payment">
                <form action="pagado.php">
                    <div class="form-group owner">
                            <label for="owner">Dueño de la cuenta</label>
                            <input type="text" class="form-control" id="owner" required>
                        </div>
                        <div class="form-group CVV">
                            <label for="cvv">CVV</label>
                            <input type="text" class="form-control" id="cvv" required>
                        </div>
                        <div class="form-group" id="card-number-field">
                            <label for="cardNumber">Numero de Tarjeta</label>
                            <input type="text" class="form-control" id="cardNumber">
                        </div>
                        <div class="agrupar form-group" id="expiration-date">
                            <label>Fecha de Expiracion</label>
                            <select>
                                <option value="01">Enero</option>
                                <option value="02">Febrero </option>
                                <option value="03">Marzo</option>
                                <option value="04">Abril</option>
                                <option value="05">Mayo</option>
                                <option value="06">Junio</option>
                                <option value="07">Julio</option>
                                <option value="08">Agosto</option>
                                <option value="09">Septiembre</option>
                                <option value="10">Octubre</option>
                                <option value="11">Noviembre</option>
                                <option value="12">Diciembre</option>
                            </select>
                            <select>
                                <option value="21"> 2021</option>
                                <option value="22"> 2022</option>
                                <option value="23"> 2023</option>
                                <option value="24"> 2024</option>
                                <option value="25"> 2025</option>
                                <option value="26"> 2026</option>
                                <option value="27"> 2027</option>
                                <option value="28"> 2028</option>
                                <option value="29"> 2029</option>
                            </select>
                        </div>
                        <div class="form-group" id="credit_cards">
                            <img src="assets/images/visa.jpg" id="visa">
                            <img src="assets/images/mastercard.jpg" id="mastercard">
                            <img src="assets/images/amex.jpg" id="amex">
                        </div>
                    <div class="form-group" id="pay-now">
                        <button type="submit" class="boton boton-morado" id="confirm-purchase">Confirmar</button>
                        <div id="paypal-button-container"></div>
                    </div>
                </form>
                    <!-- Include the PayPal JavaScript SDK -->
                    <script src="https://www.paypal.com/sdk/js?client-id=test&currency=USD"></script>

                    <script>
                        // Render the PayPal button into #paypal-button-container
                        paypal.Buttons({
                            env: 'sandbox',
                            style: {
                                label: 'checkout',
                                size: 'responsive',
                                shape: 'pill',
                                layout: 'horizontal'
                            }
                        }).render('#paypal-button-container');
                    </script>
            </div>
        </div>

        
    </div>
    </main>
    <footer class="site-footer seccion">
        <div class="contenedor contenedor-footer">
            <div class="agrupar">
                <nav class="navegacion">
                    <a href="Nosotros.php">Conocenos</a>
                    <a href="Productos.php">Catalogo</a>
                    <a href="Vision.php">Vision</a>
                    <a href="Contacto.php">Contacto</a>
                </nav>
                <p class="copyright">ALGAR &copy;
                </p>
            </div>
            <div class="agrupar fw-400">
                <p>Torreón, Coahuila México</p>
                <p>marian.garza187@gmail.com</p>
                <p>tel: 8713351802</p>
            </div>
        </div>
    </footer>
</body>


</html>