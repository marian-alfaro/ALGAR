<?php
    require ('conexion.php');
    
    $ArregloPrecio = array();
    $ArregloImagen = array();
    $ArregloDescripcion = array();
    $ArregloNombre = array();

    $sql = "SELECT * FROM stock";
    $resultado = $conexion->query($sql);

    if($resultado->num_rows > 0)
    {
        while($row=$resultado->fetch_assoc())
        {
            array_push ($ArregloPrecio, $row["precio"]);
            array_push ($ArregloImagen, $row["imagen"]);
            array_push ($ArregloDescripcion, $row["descripcion"]);
            array_push ($ArregloNombre, $row["nombre_producto"]);
        }   
    }

    $conexion->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Last-Modified" content="0">
    <meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-A-Compatible" content="ie=edge">
    <title>ALGAR Design</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/Normalize.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/Productos.css">
    <link rel="stylesheet" href="css/stylePHP.css">
</head>

<body onload="banner()">
    <header class="site-header inicio fw-700">
        <div class="contenedor contenido-header">
            <div class="barra">
                <div style="justify-content: center; display: flex;">
                    <a href="index.php">
                        <img src="img/Logo.svg" alt="Logotipo de la pagina"></img>
                    </a>
                </div>
                <nav id="navegacion" class="navegacion-main alinear-navegador">
                    <div>
                        <a href="Nosotros.php">Conocenos</a>
                        <a href="Productos.php">Catalogo</a>
                        <a href="Vision.php">Vision</a>
                        <a href="Contacto.php">Contacto</a>
                        <?php
                        if($VarSession == NULL || $VarSession = '')
                        {
                            echo '<a href="Login.html">Inicia Sesion</a>';
                        }
                        else
                        {
                            echo '
                            <a href="CerrarSesion.php">Cerrar Sesion</a>
                        ';
                        }
                        ?>
                    </div>
                    <div class="alinear agrupar">
                        <div>
                        <a href="Carrito.php">Carrito de compra</div><div><img class ="carrito"src="img/carrito.png" alt="Carrito de Compra"></div></a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="contenedor site-main">

        <script>
        function makeArray(){for(i=0;i<makeArray.arguments.length;i++)this[i+1]=makeArray.arguments[i]}var months=new makeArray('Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre');var date=new Date();var day=date.getDate();var month=date.getMonth()+1;var yy=date.getYear();var year=(yy<1000)?yy+1900:yy;document.write("Hoy es "+day+ " de "+months[month]+" del "+year);
</script>
    <!-- MAIN WRAPPER
    <div id="wrapper">
        <div id="slide-wrap">
            <section class="slider">
            <ul class="slider1">
                <li><img src="img/1.jpg" alt=""></li>
                <li><img src="img/2.jpg" alt=""></li>
                <li><img src="img/3.jpg" alt=""></li>
                <li><img src="img/4.jpg" alt=""></li>
                <li><img src="img/5.jpg" alt=""></li>
                <li><img src="img/6.jpg" alt=""></li>
            </ul>
            </section>
        </div>
    </div>-->

        <script>
            ban = new Array(6);
            ban [0] = 'img/1.jpg';
            ban [1] = 'img/2.jpg';
            ban [2] = 'img/3.jpg';
            ban [3] = 'img/4.jpg';
            ban [4] = 'img/5.jpg';
            ban [5] = 'img/6.jpg';
            var contador = 0;
            var timer = 4000;

            function banner (){
                contador++;
                contador = contador % 6;
                document.banner.src = ban[contador];
                setTimeout ("banner()", timer);
            }
        </script>
        
        <h2 class="centrar-texto fw-700">Diseños completamente originales</h3>
        <div class="contenedor-anuncio">
            <img src="" name="banner" style="height: 45rem; margin: 2rem 0 17rem;">
        </div>

        <h2 class="centrar-texto fw-400">Lo más vendido</h2>
            <div class="contenedor-anuncio">
            <?php
                $i=0;
                while ($i < 2)
                {
                echo'
                <div class="anuncio">
                    <img src="'.$ArregloImagen[$i].'" alt="Anuncio Producto">
                    <div class="contenido-anuncio">
                        <div class="texto-anuncio">
                            <h3>'.$ArregloNombre[$i].'</h3>
                            <p>'.$ArregloDescripcion[$i].'</p>
                            <p class="precio"> $'.number_format($ArregloPrecio[$i], 0, '.', ',').'</p>
                        </div>
                        <div class="contenedor-boton">

                        //FORMULARIO INVISIBLE
                        <form action="Comprar.php" method="POST">
                        //TRES ENTRADAS DE TIPO ESCONDIDO 
                                <input type="hidden" value="'.$ArregloNombre[$i].'" name="Nombre">
                                <input type="hidden" value="'.$ArregloImagen[$i].'" name="Imagen">
                                <input type="hidden" value="'.$ArregloPrecio[$i].'" name="Precio">
                                <input type="submit" class="boton boton-pastel boton-producto d-block tamaño-boton" value="Ver Producto">
                        </form>
                        </div>
                    </div>
                </div>';
                $i++;
                }
                ?>
                </div>
            </div>

            <div class="ver-productos">
                <a class="boton boton-pastel" href="Productos.php">Ver Catalogo</a>
            </div>
            <center>
            <style>
                    div.c2 {position:absolute; left:720px; top: 2530px; width:50px; height:50px;}
                    div.c1 {position:absolute; left:820px; top: 2530px; width:50px; height:50px;}
                </style>
                    <h1>Botón huidizo</h1>
                    <script>
                    var flag=1;function t(){if(flag==1){N.style.top="2410px";N.style.left="1000px"}if(flag==2){N.style.top="2330px";N.style.left="400px"}if(flag==3){N.style.top="2530px";N.style.left="820px"}flag=flag+1;if(flag==4){flag=1}}function al(){alert("Correcto!")}
                    </script>
                    
                    //CÓDIGO DEL BOTON HUIDIZO 
                    ALGAR Design es un sitio es muy interesante?
                        <div id="N" class="c1">
                        <form>
                            <input type="button" value="NO" onmouseover="t()" />
                        </form>
                        </div>
                        <div id="Y" class="c2">
                        <form>
                            <input type="button" value="SI" onclick="al()" />
                        </form>
                        </div>
        </center>
    </main>

    <footer class="site-footer seccion">
        <div class="contenedor contenedor-footer">
            <div class="agrupar">
                <nav class="navegacion">
                    <a href="Nosotros.php">Conocenos</a>
                    <a href="Productos.php">Catalogo</a>
                    <a href="Vision.php">Vision</a>
                    <a href="Contacto.php">Contacto</a>
                </nav>
                <p class="copyright">ALGAR &copy;
                </p>
            </div>
            <div class="agrupar fw-400">
                <p>Torreón, Coahuila México</p>
                <p>marian.garza187@gmail.com</p>
                <p>tel: 8713351802</p>
            </div>
        </div>
    </footer>
</body>


</html>